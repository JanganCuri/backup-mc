scoreboard objectives add horseHundred dummy
scoreboard players set @s horseHundred 100
scoreboard objectives add horseTen dummy
scoreboard players set @s horseTen 10
execute as @e[type=horse,sort=nearest,limit=1] store result score @p horseHealth run data get entity @s Attributes[{Name:"minecraft:generic.max_health"}].Base 1
execute as @e[type=horse,sort=nearest,limit=1] store result score @p horseJump run data get entity @s Attributes[{Name:"minecraft:horse.jump_strength"}].Base 100
execute as @e[type=horse,sort=nearest,limit=1] store result score @p horseSpeed run data get entity @s Attributes[{Name:"minecraft:generic.movement_speed"}].Base 4317
scoreboard players operation @s horseJumpDec = @s horseJump
scoreboard players operation @s horseJumpDec %= @s horseTen
scoreboard players operation @s horseSpeedDec = @s horseSpeed
scoreboard players operation @s horseSpeedDec %= @s horseHundred
scoreboard players operation @s horseJump -= horseJumpDec
scoreboard players operation @s horseSpeed -= horseSpeedDec
scoreboard players operation @s horseJump /= @s horseTen
scoreboard players operation @s horseSpeed /= @s horseHundred
title @s clear
title @s actionbar [{"text":"Health: ","color":"red"}, {"score":{"name":"@s","objective":"horseHealth"},"color":"blue"}, {"text":"   Jump: ","color":"aqua"}, {"score":{"name":"@s","objective":"horseJump"},"color":"blue"}, {"text":".","color":"blue"}, {"score":{"name":"@s","objective":"horseJumpDec"},"color":"blue"}, {"text":"   Speed (b/s): ","color":"green"}, {"score":{"name":"@s","objective":"horseSpeed"},"color":"blue"},{"text":".","color":"blue"}, {"score":{"name":"@s","objective":"horseSpeedDec"},"color":"blue"}]
scoreboard objectives remove horseHundred
scoreboard objectives remove horseTen
scoreboard players reset @a horseHealth
scoreboard players reset @a horseSpeed
scoreboard players reset @a horseJump
scoreboard players reset @a horseSpeedDec
scoreboard players reset @a horseJumpDec
advancement revoke @s only horsestats:horse_stats_trigger
