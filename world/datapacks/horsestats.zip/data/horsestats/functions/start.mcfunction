scoreboard objectives add horseHealth dummy
scoreboard objectives add horseSpeed dummy
scoreboard objectives add horseJump dummy
scoreboard objectives add horseSpeedDec dummy
scoreboard objectives add horseJumpDec dummy
advancement revoke @s only horsestats:horse_stats_trigger